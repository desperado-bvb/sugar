package agent

import (
	"time"
)

const (
	VERSION = "0.0.1"

	DEFAULT_KEEPAlIVE = 300

	ACCEPT_MIN_SLEEP = 1 * time.Second

        ACCEPT_MAX_SLEEP = 300 * time.Second
)
